using System.Collections.Generic;

namespace ImageMusicPlayer.Interfaces
{
    public interface IMusicPlayer
    {
        void RemoveCurrentFromPlaylist();
        void Stop();
        void PlayAt(int index);
        string CurrentPath { get; }
        PlayMode Mode { get; set; }
        List<string> PlayPathList { get; set; }
        void Play(string path);
        string LoadLastPlayed();
        void Pause();
        void PlayNext();
        void PlayPrevious();
        int GetVolume();
        void SetVolume(int value);
    }
}

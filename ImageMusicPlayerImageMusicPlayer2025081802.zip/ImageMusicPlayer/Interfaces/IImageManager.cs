using System;
using System.Threading.Tasks;

namespace ImageMusicPlayer.Interfaces
{
    public interface IImageManager
    {
        void Init(ImageViewer viewer, Action statusUpdater, int cacheSize);
        string CurrentImagePath { get; }
        int CurrentIndex { get; }
        int TotalCount { get; }
        int CacheCount { get; }
        Task SelectAndLoadFromFolderAsync();
        Task LoadFromFolderAsync(string folderPath);
        Task SelectAndAppendImagesAsync();
        Task SelectAndAppendImagesAsync(string[] files);
        void NextImage();
        void PreviousImage();
        Task RemoveImagesFromFolder(string folderPath);
        Task RemoveImage(string imagePath);
        Task DeleteCurrentImageAsync();
        Task StartSlideShowAsync(Func<int> getDelay);
        void PauseSlideShow();
    }
}

using System;
using System.Drawing;

public interface IImageViewer
{
    float Zoom { get; }
    void LoadImage(Image img);
    void ResetView();
    event EventHandler ZoomChanged;
}

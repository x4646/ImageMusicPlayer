using System;
using System.Collections.Generic;
using ImageMusicPlayer.Models;

public class ImageCache
{
    private IList<string> sourceCollection;
    private readonly LinkedList<CachedImage> cache = new LinkedList<CachedImage>();
    private LinkedListNode<CachedImage> current;
    private readonly int totalCacheSize;
    private int forwardRatio;
    private int backwardRatio;

    // 委托：通过路径加载图片
    public Func<string, CachedImage> loadImageFunc;

    // 当前在数据源中的索引
    private int _currentIndex = 0;

    // 为兼容旧代码，保留但不再参与核心逻辑
    public int CurrentSourceIndex { private get; set; }

    public int CurrentCachedSize { get { return cache.Count; } }

    public ImageCache(int? totalCacheSize)
    {
        if (totalCacheSize == null || totalCacheSize < 15)
            totalCacheSize = 15;
        this.totalCacheSize = totalCacheSize.Value;
    }

    public void Init(IList<string> sourceCollection)
    {
        Clear();
        this.sourceCollection = sourceCollection ?? new List<string>();
        _currentIndex = 0;

        forwardRatio = (int)Math.Ceiling(totalCacheSize * 0.75);
        backwardRatio = totalCacheSize - forwardRatio;

        // 预热缓存窗口：从0开始，最多 forwardRatio 张
        for (int i = 0; i < forwardRatio && i < this.sourceCollection.Count; i++)
        {
            string path = this.sourceCollection[i];
            cache.AddLast(loadImageFunc(path));
        }
        current = cache.First;
    }

    private string GetImagePath(int index)
    {
        if (index < 0 || sourceCollection == null || index >= sourceCollection.Count)
            throw new ArgumentOutOfRangeException("index", "索引超出范围。");
        return sourceCollection[index];
    }

    public CachedImage GetCurrent()
    {
        if (current == null) throw new InvalidOperationException("缓存未初始化或为空。");
        return current.Value;
    }

    public void Clear()
    {
        _currentIndex = 0;
        foreach (var img in cache)
        {
            img.Dispose();
        }
        cache.Clear();
        current = null;
    }

    public CachedImage Next()
    {
        if (sourceCollection == null || sourceCollection.Count == 0)
            throw new InvalidOperationException("数据源为空。");

        if (current == null)
        {
            Init(sourceCollection);
            return current.Value;
        }

        if (current.Next != null)
        {
            current = current.Next;
            _currentIndex = Math.Min(_currentIndex + 1, sourceCollection.Count - 1);
        }
        else
        {
            if (_currentIndex < sourceCollection.Count - 1)
            {
                _currentIndex++;
                cache.AddLast(loadImageFunc(GetImagePath(_currentIndex)));
                current = current.Next;
            }
            else
            {
                // 保持原有回绕体验：到末尾后回到开头
                _currentIndex = 0;
                cache.AddLast(loadImageFunc(GetImagePath(_currentIndex)));
                current = cache.Last;
            }
        }

        // 保证从当前到尾部不少于 forwardRatio
        while (CountFromCurrent() < forwardRatio && _currentIndex < sourceCollection.Count - 1)
        {
            int nextIdx = _currentIndex + 1;
            if (nextIdx <= sourceCollection.Count - 1)
            {
                _currentIndex = nextIdx;
                cache.AddLast(loadImageFunc(GetImagePath(_currentIndex)));
            }
            else break;
        }

        // 回收头部超出
        while (CountBeforeCurrent() > backwardRatio)
        {
            var first = cache.First;
            if (first != null)
            {
                first.Value.Dispose();
                cache.RemoveFirst();
            }
            else break;
        }

        return current.Value;
    }

    public CachedImage Previous()
    {
        if (sourceCollection == null || sourceCollection.Count == 0)
            throw new InvalidOperationException("数据源为空。");

        if (current == null)
        {
            Init(sourceCollection);
            return current.Value;
        }

        if (current.Previous != null)
        {
            current = current.Previous;
            _currentIndex = Math.Max(_currentIndex - 1, 0);
        }
        else
        {
            if (_currentIndex > 0)
            {
                _currentIndex--;
                cache.AddFirst(loadImageFunc(GetImagePath(_currentIndex)));
                current = cache.First;
            }
            else
            {
                // 从头部回绕到尾部
                _currentIndex = sourceCollection.Count - 1;
                cache.AddFirst(loadImageFunc(GetImagePath(_currentIndex)));
                current = cache.First;
            }
        }

        // 保证头部(含当前)不少于 forwardRatio
        while (CountBeforeCurrent() + 1 < forwardRatio && _currentIndex > 0)
        {
            int prevIdx = _currentIndex - 1;
            if (prevIdx >= 0)
            {
                _currentIndex = prevIdx;
                cache.AddFirst(loadImageFunc(GetImagePath(_currentIndex)));
                current = cache.First;
            }
            else break;
        }

        // 回收尾部超出
        while (CountAfterCurrent() > backwardRatio)
        {
            var last = cache.Last;
            if (last != null)
            {
                last.Value.Dispose();
                cache.RemoveLast();
            }
            else break;
        }

        return current.Value;
    }

    private int CountBeforeCurrent()
    {
        int count = 0;
        var node = cache.First;
        while (node != null && node != current)
        {
            count++;
            node = node.Next;
        }
        return count;
    }

    private int CountFromCurrent()
    {
        int count = 0;
        var node = current;
        while (node != null)
        {
            count++;
            node = node.Next;
        }
        return count;
    }

    private int CountAfterCurrent()
    {
        int count = 0;
        var node = (current != null) ? current.Next : null;
        while (node != null)
        {
            count++;
            node = node.Next;
        }
        return count;
    }
}

﻿using System.Drawing;
using System.Drawing.Drawing2D;

namespace ImageMusicPlayer.Services
{
    public static class ThumbnailHelper
    {
        /// <summary>
        /// 生成等比缩略图（最长边限制为 maxEdge）
        /// </summary>
        public static Image CreateThumb(Image src, int maxEdge)
        {
            if (src.Width <= maxEdge && src.Height <= maxEdge) return (Image)src.Clone();

            float scale = (float)maxEdge / (src.Width > src.Height ? src.Width : src.Height);
            int w = (int)(src.Width * scale);
            int h = (int)(src.Height * scale);

            var bmp = new Bitmap(w, h);
            using var g = Graphics.FromImage(bmp);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.DrawImage(src, 0, 0, w, h);
            return bmp;
        }
    }
}

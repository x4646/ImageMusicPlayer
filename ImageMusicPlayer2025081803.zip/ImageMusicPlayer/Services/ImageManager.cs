﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImageMusicPlayer.Interfaces;

namespace ImageMusicPlayer.Services
{
    /// <summary>
    /// 图片管理器：缩略图优先 + 放大异步补原图；仅在必要场景 ResetView
    /// </summary>
    public class ImageManager : IImageManager
    {
        // ===== 可调参数 =====
        private const float FullQualityZoomThreshold = 1.05f; // 缩放超过该阈值时加载原图
        private const int ThumbMaxEdge = 1600;                 // 缩略图最长边
        private const int FullCacheLimit = 2;                  // 原图 LRU 缓存上限
        private const int PlaceholderW = 800;
        private const int PlaceholderH = 600;

        // ===== 依赖（支持先 new 再 Init，所以不 readonly）=====
        private IImageViewer _viewer;
        private Action _updateStatus = () => { };
        private int _prefetch = 3;

        // ===== 状态 =====
        private readonly List<string> _files = new List<string>();
        private int _index = -1;

        // 缩略图缓存：path -> Image
        private readonly Dictionary<string, Image> _thumbCache =
            new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);

        // 原图缓存（LRU）
        private readonly Dictionary<string, Image> _fullCache =
            new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);
        private readonly LinkedList<string> _fullLru = new LinkedList<string>();

        // 异步控制
        private CancellationTokenSource _fullLoadCts;
        private volatile bool _slideshowPaused = false;

        // UI 同步
        private readonly SynchronizationContext _ui =
            SynchronizationContext.Current ?? new SynchronizationContext();

        // ========= 构造 =========
        public ImageManager() { } // 兼容：先 new 再 Init

        public ImageManager(IImageViewer imageViewer, Action updateStatus, int prefetch)
        {
            Init(imageViewer, updateStatus, prefetch);
        }

        // ========= Init（推荐入口）=========
        public void Init(IImageViewer imageViewer, Action updateStatus, int prefetch)
        {
            _viewer = imageViewer ?? throw new ArgumentNullException(nameof(imageViewer));
            _updateStatus = updateStatus ?? (() => { });
            _prefetch = Math.Max(1, prefetch);

            // 避免重复订阅
            _viewer.ZoomChanged -= Viewer_ZoomChanged;
            _viewer.ZoomChanged += Viewer_ZoomChanged;
        }

        // ========= 兼容旧签名：ImageManager.Init(ImageViewer, Action, int) =========
        // 注意：参数是具体类 ImageViewer（非接口），和你报错中的签名一致
        public void Init(ImageMusicPlayer.ImageViewer imageViewer, Action updateStatus, int prefetch)
        {
            Init((IImageViewer)imageViewer, updateStatus, prefetch);
        }

        // ========= IImageManager 属性 =========
        public string CurrentImagePath
        {
            get
            {
                if (_index < 0 || _index >= _files.Count) return string.Empty;
                return _files[_index];
            }
        }

        public int CurrentIndex { get { return _index; } }
        public int TotalCount { get { return _files.Count; } }
        public int CacheCount { get { return _thumbCache.Count; } }

        // ========= IImageManager：加载/追加 =========
        public async Task SelectAndLoadFromFolderAsync()
        {
            EnsureInited();

            using (var fbd = new FolderBrowserDialog())
            {
                fbd.Description = "请选择图片文件夹：";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    await LoadFromFolderAsync(fbd.SelectedPath);
                }
            }
        }

        public async Task LoadFromFolderAsync(string folderPath)
        {
            EnsureInited();

            if (string.IsNullOrEmpty(folderPath) || !Directory.Exists(folderPath)) return;

            var exts = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { ".jpg",".jpeg",".png",".bmp",".gif",".webp",".tif",".tiff" };

            var files = Directory.EnumerateFiles(folderPath, "*.*", SearchOption.AllDirectories)
                                 .Where(p => exts.Contains(Path.GetExtension(p)))
                                 .ToList();
            if (files.Count == 0) return;

            ResetAllCaches();

            _files.AddRange(files);
            // 首次显示：重置视图
            ShowImageAt(0, resetView: true);

            await Task.Run(() => PrefetchThumbs(_index + 1, _prefetch));
        }

        public async Task SelectAndAppendImagesAsync()
        {
            EnsureInited();

            using (var ofd = new OpenFileDialog())
            {
                ofd.Multiselect = true;
                ofd.Filter = "图片文件|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.webp;*.tif;*.tiff";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    await SelectAndAppendImagesAsync(ofd.FileNames);
                }
            }
        }

        public Task SelectAndAppendImagesAsync(string[] files)
        {
            EnsureInited();

            if (files != null && files.Length > 0)
            {
                foreach (var f in files)
                {
                    if (!_files.Contains(f, StringComparer.OrdinalIgnoreCase))
                        _files.Add(f);
                }
            }
            _updateStatus();
            return Task.CompletedTask;
        }

        // ========= IImageManager：切换 =========
        public void NextImage()
        {
            EnsureInited();
            if (_files.Count == 0) return;

            int next = (_index + 1 >= _files.Count) ? _files.Count - 1 : _index + 1;
            ShowImageAt(next, resetView: false);   // 不重置，保留拖拽/缩放
            Task.Run(() => PrefetchThumbs(_index + 1, _prefetch));
        }

        public void PreviousImage()
        {
            EnsureInited();
            if (_files.Count == 0) return;

            int prev = (_index - 1 < 0) ? 0 : _index - 1;
            ShowImageAt(prev, resetView: false);   // 不重置
            Task.Run(() => PrefetchThumbs(_index + 1, _prefetch));
        }

        // ========= IImageManager：移除/删除 =========
        public Task RemoveImagesFromFolder(string folderPath)
        {
            EnsureInited();

            if (string.IsNullOrEmpty(folderPath)) return Task.CompletedTask;

            var toRemove = _files.Where(p => p.StartsWith(folderPath, StringComparison.OrdinalIgnoreCase)).ToList();
            foreach (var p in toRemove)
            {
                RemoveFromCaches(p);
                _files.Remove(p);
            }

            if (_files.Count == 0)
            {
                _index = -1;
                _viewer.LoadImage(null);
            }
            else
            {
                if (_index >= _files.Count) _index = _files.Count - 1;
                ShowImageAt(_index, resetView: true); // 换了数据集，重置一次
            }

            _updateStatus();
            return Task.CompletedTask;
        }

        public Task RemoveImage(string imagePath)
        {
            EnsureInited();

            if (string.IsNullOrEmpty(imagePath)) return Task.CompletedTask;

            int idx = _files.FindIndex(p => string.Equals(p, imagePath, StringComparison.OrdinalIgnoreCase));
            if (idx >= 0)
            {
                RemoveFromCaches(imagePath);
                _files.RemoveAt(idx);

                if (_files.Count == 0)
                {
                    _index = -1;
                    _viewer.LoadImage(null);
                }
                else
                {
                    if (_index >= _files.Count) _index = _files.Count - 1;
                    ShowImageAt(_index, resetView: true); // 删除当前后切到邻居，重置一次
                }
                _updateStatus();
            }
            return Task.CompletedTask;
        }

        public async Task DeleteCurrentImageAsync()
        {
            EnsureInited();

            var p = CurrentImagePath;
            if (string.IsNullOrEmpty(p)) return;

            try { if (File.Exists(p)) File.Delete(p); } catch { }
            await RemoveImage(p);
        }

        // ========= IImageManager：幻灯片 =========
        public async Task StartSlideShowAsync(Func<int> getDelay)
        {
            EnsureInited();

            _slideshowPaused = false;
            while (!_slideshowPaused && _files.Count > 0)
            {
                int next = (_index + 1) % _files.Count;
                ShowImageAt(next, resetView: false); // 幻灯片不重置
                int delay = 1500;
                try { delay = Math.Max(300, getDelay != null ? getDelay() : 1500); } catch { }
                await Task.Delay(delay);
            }
        }

        public void PauseSlideShow()
        {
            _slideshowPaused = true;
        }

        // ========= 缩放事件：触发原图补全 =========
        private void Viewer_ZoomChanged(object sender, EventArgs e)
        {
            if (_viewer == null) return;
            if (_viewer.Zoom <= FullQualityZoomThreshold) return;

            var path = CurrentImagePath;
            if (string.IsNullOrEmpty(path)) return;

            Image full;
            if (TryGetFullFromCache(path, out full))
            {
                // 仅替换位图，不重置视图
                _viewer.LoadImage(full);
            }
            else
            {
                EnsureFullAsync(path);
            }
        }

        // ========= 显示统一入口（是否重置视图）=========
        private void ShowImageAt(int index, bool resetView)
        {
            if (index < 0 || index >= _files.Count) return;

            CancelFullLoad();
            _index = index;

            string path = _files[index];

            // 先用缩略图立即显示
            Image thumb = GetOrBuildThumb(path);
            _viewer.LoadImage(thumb);
            if (resetView) _viewer.ResetView(); // 仅在必要场景重置
            _updateStatus();

            // 若当前已是放大状态，则补原图
            if (_viewer.Zoom > FullQualityZoomThreshold)
            {
                EnsureFullAsync(path);
            }
        }

        // ========= 原图/缩略图：生成与缓存 =========
        private Image GetOrBuildThumb(string path)
        {
            Image cached;
            if (_thumbCache.TryGetValue(path, out cached) && cached != null)
                return cached;

            FileStream fs = null;
            Image src = null;
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                src = Image.FromStream(fs, true, false);
                var thumb = BuildThumb(src, ThumbMaxEdge);
                _thumbCache[path] = thumb;
                return thumb;
            }
            catch
            {
                // 占位图
                var bmp = new Bitmap(PlaceholderW, PlaceholderH);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.Black);
                    using (var br = new SolidBrush(Color.White))
                    using (var font = new Font("Segoe UI", 12))
                    {
                        g.DrawString("加载失败", font, br, new PointF(20, 20));
                    }
                }
                _thumbCache[path] = bmp;
                return bmp;
            }
            finally
            {
                try { if (src != null) src.Dispose(); } catch { }
                try { if (fs != null) fs.Dispose(); } catch { }
            }
        }

        private static Image BuildThumb(Image src, int maxEdge)
        {
            if (src.Width <= maxEdge && src.Height <= maxEdge)
                return (Image)src.Clone();

            float scale = (float)maxEdge / (src.Width > src.Height ? src.Width : src.Height);
            int w = Math.Max(1, (int)(src.Width * scale));
            int h = Math.Max(1, (int)(src.Height * scale));

            var bmp = new Bitmap(w, h);
            using (var g = Graphics.FromImage(bmp))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                g.DrawImage(src, 0, 0, w, h);
            }
            return bmp;
        }

        private void EnsureFullAsync(string path)
        {
            CancelFullLoad();
            _fullLoadCts = new CancellationTokenSource();
            var token = _fullLoadCts.Token;

            Task.Run(() =>
            {
                if (token.IsCancellationRequested) return;

                FileStream fs = null;
                Image tmp = null;
                Image full = null;
                try
                {
                    fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    tmp = Image.FromStream(fs, true, false);
                    if (token.IsCancellationRequested) return;
                    full = (Image)tmp.Clone();
                }
                catch
                {
                    // 读取失败：静默返回
                    return;
                }
                finally
                {
                    try { if (tmp != null) tmp.Dispose(); } catch { }
                    try { if (fs != null) fs.Dispose(); } catch { }
                }

                if (token.IsCancellationRequested)
                {
                    try { if (full != null) full.Dispose(); } catch { }
                    return;
                }

                PutFullIntoCache(path, full);

                if (string.Equals(path, CurrentImagePath, StringComparison.OrdinalIgnoreCase))
                {
                    _ui.Post(_ => _viewer.LoadImage(full), null); // 仅替换，不重置
                }
            });
        }

        private void PrefetchThumbs(int startIndex, int count)
        {
            if (_files.Count == 0 || startIndex >= _files.Count || count <= 0) return;
            int end = Math.Min(_files.Count - 1, startIndex + count - 1);
            for (int i = startIndex; i <= end; i++)
            {
                string p = _files[i];
                Image dummy;
                if (!_thumbCache.TryGetValue(p, out dummy))
                {
                    try { GetOrBuildThumb(p); } catch { }
                }
            }
        }

        // ========= 原图缓存（LRU）=========
        private void PutFullIntoCache(string path, Image img)
        {
            Image existing;
            if (_fullCache.TryGetValue(path, out existing))
            {
                MoveKeyToLruHead(path);
                if (!object.ReferenceEquals(existing, img))
                {
                    try { existing.Dispose(); } catch { }
                    _fullCache[path] = img;
                }
                return;
            }

            _fullCache[path] = img;
            _fullLru.AddFirst(path);

            if (_fullCache.Count > FullCacheLimit)
            {
                var tail = _fullLru.Last;
                if (tail != null)
                {
                    string k = tail.Value;
                    _fullLru.RemoveLast();
                    Image old;
                    if (_fullCache.TryGetValue(k, out old))
                    {
                        _fullCache.Remove(k);
                        try { old.Dispose(); } catch { }
                    }
                }
            }
        }

        private bool TryGetFullFromCache(string path, out Image img)
        {
            if (_fullCache.TryGetValue(path, out img))
            {
                MoveKeyToLruHead(path);
                return true;
            }
            img = null;
            return false;
        }

        private void MoveKeyToLruHead(string path)
        {
            var node = _fullLru.Find(path);
            if (node != null)
            {
                _fullLru.Remove(node);
                _fullLru.AddFirst(node);
            }
        }

        // ========= 工具/清理 =========
        private void EnsureInited()
        {
            if (_viewer == null)
                throw new InvalidOperationException("ImageManager 未初始化。请先调用 Init(...) 或使用带参构造函数。");
        }

        private void CancelFullLoad()
        {
            var cts = _fullLoadCts;
            if (cts != null)
            {
                try { cts.Cancel(); } catch { }
                try { cts.Dispose(); } catch { }
                _fullLoadCts = null;
            }
        }

        private void RemoveFromCaches(string path)
        {
            Image img;
            if (_thumbCache.TryGetValue(path, out img))
            {
                _thumbCache.Remove(path);
                try { img.Dispose(); } catch { }
            }

            if (_fullCache.TryGetValue(path, out img))
            {
                _fullCache.Remove(path);
                try { img.Dispose(); } catch { }
            }

            var node = _fullLru.Find(path);
            if (node != null) _fullLru.Remove(node);
        }

        private void ResetAllCaches()
        {
            CancelFullLoad();

            foreach (var kv in _thumbCache)
                try { kv.Value.Dispose(); } catch { }
            _thumbCache.Clear();

            foreach (var kv in _fullCache)
                try { kv.Value.Dispose(); } catch { }
            _fullCache.Clear();
            _fullLru.Clear();

            _files.Clear();
            _index = -1;
        }
    }
}

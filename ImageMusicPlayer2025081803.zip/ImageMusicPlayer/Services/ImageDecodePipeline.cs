using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace ImageMusicPlayer.Perf
{
    /// <summary>
    /// 高性能图片解码 + 按显示尺寸缩放 + LRU 内存缓存 + 后台预取
    /// 兼容 .NET Framework 4.8 / C#7。
    /// </summary>
    public sealed class ImageDecodePipeline : IDisposable
    {
        private readonly Size targetSize;
        private readonly int maxEntries;
        private readonly int degreeOfParallelism;

        private readonly ConcurrentDictionary<string, LinkedListNode<Entry>> map
            = new ConcurrentDictionary<string, LinkedListNode<Entry>>();
        private readonly LinkedList<Entry> lru = new LinkedList<Entry>();
        private readonly object lruLock = new object();

        private readonly BlockingCollection<string> queue = new BlockingCollection<string>(new ConcurrentQueue<string>());
        private readonly List<Task> workers = new List<Task>();
        private readonly CancellationTokenSource cts = new CancellationTokenSource();

        private struct Entry
        {
            public string Key;
            public Bitmap Bmp;
        }

        public ImageDecodePipeline(Size targetSize, int maxEntries = 96, int degreeOfParallelism = 2)
        {
            if (targetSize.Width <= 0 || targetSize.Height <= 0) targetSize = new Size(1600, 900);
            if (maxEntries < 16) maxEntries = 16;
            if (degreeOfParallelism < 1) degreeOfParallelism = 1;

            this.targetSize = targetSize;
            this.maxEntries = maxEntries;
            this.degreeOfParallelism = degreeOfParallelism;

            for (int i = 0; i < this.degreeOfParallelism; i++)
                workers.Add(Task.Run(() => Worker(cts.Token), cts.Token));
        }

        public void Enqueue(IEnumerable<string> paths)
        {
            if (paths == null) return;
            foreach (var p in paths)
            {
                if (!string.IsNullOrEmpty(p) && File.Exists(p))
                    queue.Add(p);
            }
        }

        public Bitmap GetOrDecode(string path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            var key = MakeKey(path);

            LinkedListNode<Entry> node;
            if (map.TryGetValue(key, out node))
            {
                lock (lruLock)
                {
                    lru.Remove(node);
                    lru.AddFirst(node);
                }
                return node.Value.Bmp;
            }

            var bmp = DecodeFast(path, targetSize);
            Put(key, bmp);
            return bmp;
        }

        private void Worker(CancellationToken token)
        {
            foreach (var path in queue.GetConsumingEnumerable(token))
            {
                try
                {
                    var key = MakeKey(path);
                    if (map.ContainsKey(key)) continue;
                    var bmp = DecodeFast(path, targetSize);
                    Put(key, bmp);
                }
                catch { /* swallow per-item errors */ }
            }
        }

        private void Put(string key, Bitmap bmp)
        {
            if (bmp == null) return;
            var node = new LinkedListNode<Entry>(new Entry { Key = key, Bmp = bmp });
            lock (lruLock)
            {
                lru.AddFirst(node);
                map[key] = node;
                while (lru.Count > maxEntries)
                {
                    var last = lru.Last;
                    if (last != null)
                    {
                        lru.RemoveLast();
                        LinkedListNode<Entry> _;
                        map.TryRemove(last.Value.Key, out _);
                        try { last.Value.Bmp.Dispose(); } catch { }
                    }
                    else break;
                }
            }
        }

        private static Bitmap DecodeFast(string path, Size target)
        {
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var img = Image.FromStream(fs, false, false))
            {
                double sx = (double)target.Width / img.Width;
                double sy = (double)target.Height / img.Height;
                double scale = Math.Min(sx, sy);
                if (scale > 1.0) scale = 1.0;

                int w = Math.Max(1, (int)Math.Round(img.Width * scale));
                int h = Math.Max(1, (int)Math.Round(img.Height * scale));

                var bmp = new Bitmap(w, h, PixelFormat.Format24bppRgb);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.CompositingMode = CompositingMode.SourceCopy;
                    g.CompositingQuality = CompositingQuality.HighSpeed;
                    g.InterpolationMode = InterpolationMode.Low;
                    g.SmoothingMode = SmoothingMode.None;
                    g.PixelOffsetMode = PixelOffsetMode.None;
                    g.DrawImage(img, 0, 0, w, h);
                }
                return bmp;
            }
        }

        private string MakeKey(string path)
        {
            return path + "@" + targetSize.Width + "x" + targetSize.Height;
        }

        public void Dispose()
        {
            try { queue.CompleteAdding(); } catch { }
            try { cts.Cancel(); } catch { }
            try { Task.WaitAll(workers.ToArray(), 800); } catch { }
            lock (lruLock)
            {
                for (var n = lru.First; n != null; n = n.Next)
                {
                    try { n.Value.Bmp.Dispose(); } catch { }
                }
                lru.Clear();
                map.Clear();
            }
        }
    }
}

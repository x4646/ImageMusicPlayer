using System;
using System.Collections.Generic;
using System.Drawing;
using ImageMusicPlayer.Models; // CachedImage
using ImageMusicPlayer.Perf;   // ImageDecodePipeline

public class ImageCache : IDisposable
{
    private IList<string> sourceCollection;
    private readonly LinkedList<CachedImage> cache = new LinkedList<CachedImage>();
    private LinkedListNode<CachedImage> current;
    private readonly int totalCacheSize;
    private int forwardRatio;
    private int backwardRatio;
    private int _currentIndex = 0;

    // 外部仍可注入创建逻辑；若为 null，将使用流水线默认创建
    public Func<string, CachedImage> loadImageFunc;

    // ★ 新增：解码流水线（内部持有）
    private ImageDecodePipeline _pipeline;

    public int CurrentCachedSize { get { return cache.Count; } }

    public ImageCache(int? totalCacheSize)
    {
        if (totalCacheSize == null || totalCacheSize < 15) totalCacheSize = 15;
        this.totalCacheSize = totalCacheSize.Value;
    }

    public void Init(IList<string> sourceCollection, Size? targetSize = null, int? maxEntries = null, int dop = 2)
    {
        Clear();

        this.sourceCollection = sourceCollection ?? new List<string>();
        _currentIndex = 0;

        forwardRatio = (int)Math.Ceiling(totalCacheSize * 0.75);
        backwardRatio = totalCacheSize - forwardRatio;

        // ★ 初始化流水线（targetSize 拿不到就 1600x900）
        var ts = (targetSize.HasValue && targetSize.Value.Width > 0 && targetSize.Value.Height > 0)
                 ? targetSize.Value : new Size(1600, 900);
        _pipeline?.Dispose();
        _pipeline = new ImageDecodePipeline(ts, maxEntries: Math.Max(96, (maxEntries ?? 96)), degreeOfParallelism: Math.Max(1, dop));

        // 预热窗口
        for (int i = 0; i < forwardRatio && i < this.sourceCollection.Count; i++)
        {
            string path = this.sourceCollection[i];
            cache.AddLast(CreateCached(path));
        }
        current = cache.First;

        PrefetchAround(_currentIndex);
    }

    private CachedImage CreateCached(string path)
    {
        if (loadImageFunc != null) return loadImageFunc(path);      // 外部自定义的优先
        var bmp = _pipeline.GetOrDecode(path);                      // 默认：走流水线
        return new CachedImage(path, bmp);                          // ★ 按你项目的构造改
    }

    public CachedImage GetCurrent()
    {
        if (current == null) throw new InvalidOperationException("缓存未初始化或为空。");
        return current.Value;
    }

    public void Clear()
    {
        _currentIndex = 0;
        foreach (var img in cache)
            img.Dispose();
        cache.Clear();
        current = null;

        _pipeline?.Dispose();    // ★ 释放流水线（位图 LRU）
        _pipeline = null;
    }

    public CachedImage Next()
    {
        if (sourceCollection == null || sourceCollection.Count == 0)
            throw new InvalidOperationException("数据源为空。");

        if (current == null)
        {
            // 未 Init 时兜底
            Init(sourceCollection);
            return current.Value;
        }

        if (current.Next != null)
        {
            current = current.Next;
            _currentIndex = Math.Min(_currentIndex + 1, sourceCollection.Count - 1);
        }
        else
        {
            if (_currentIndex < sourceCollection.Count - 1)
            {
                _currentIndex++;
                cache.AddLast(CreateCached(sourceCollection[_currentIndex]));
                current = current.Next;
            }
            else
            {
                _currentIndex = 0; // 回绕
                cache.AddLast(CreateCached(sourceCollection[_currentIndex]));
                current = cache.Last;
            }
        }

        // 保障窗口
        while (CountFromCurrent() < forwardRatio && _currentIndex < sourceCollection.Count - 1)
        {
            int nextIdx = _currentIndex + 1;
            if (nextIdx <= sourceCollection.Count - 1)
            {
                _currentIndex = nextIdx;
                cache.AddLast(CreateCached(sourceCollection[_currentIndex]));
            }
            else break;
        }

        // 回收头部
        while (CountBeforeCurrent() > backwardRatio)
        {
            var first = cache.First;
            if (first != null)
            {
                first.Value.Dispose();
                cache.RemoveFirst();
            }
            else break;
        }

        PrefetchAround(_currentIndex); // ★ 预取
        return current.Value;
    }

    public CachedImage Previous()
    {
        if (sourceCollection == null || sourceCollection.Count == 0)
            throw new InvalidOperationException("数据源为空。");

        if (current == null)
        {
            Init(sourceCollection);
            return current.Value;
        }

        if (current.Previous != null)
        {
            current = current.Previous;
            _currentIndex = Math.Max(_currentIndex - 1, 0);
        }
        else
        {
            if (_currentIndex > 0)
            {
                _currentIndex--;
                cache.AddFirst(CreateCached(sourceCollection[_currentIndex]));
                current = cache.First;
            }
            else
            {
                _currentIndex = sourceCollection.Count - 1; // 回绕
                cache.AddFirst(CreateCached(sourceCollection[_currentIndex]));
                current = cache.First;
            }
        }

        // 保证头部(含当前)不少于 forwardRatio
        while (CountBeforeCurrent() + 1 < forwardRatio && _currentIndex > 0)
        {
            int prevIdx = _currentIndex - 1;
            if (prevIdx >= 0)
            {
                _currentIndex = prevIdx;
                cache.AddFirst(CreateCached(sourceCollection[_currentIndex]));
                current = cache.First;
            }
            else break;
        }

        // 回收尾部
        while (CountAfterCurrent() > backwardRatio)
        {
            var last = cache.Last;
            if (last != null)
            {
                last.Value.Dispose();
                cache.RemoveLast();
            }
            else break;
        }

        PrefetchAround(_currentIndex); // ★ 预取
        return current.Value;
    }

    private void PrefetchAround(int index)
    {
        if (sourceCollection == null || sourceCollection.Count == 0 || _pipeline == null) return;

        var want = new List<string>(12);
        for (int i = 1; i <= 6; i++)
        {
            int f = index + i; if (f < sourceCollection.Count) want.Add(sourceCollection[f]);
            int b = index - i; if (b >= 0) want.Add(sourceCollection[b]);
        }
        _pipeline.Enqueue(want);
    }

    private int CountBeforeCurrent()
    {
        int count = 0;
        var node = cache.First;
        while (node != null && node != current) { count++; node = node.Next; }
        return count;
    }

    private int CountFromCurrent()
    {
        int count = 0;
        var node = current;
        while (node != null) { count++; node = node.Next; }
        return count;
    }

    private int CountAfterCurrent()
    {
        int count = 0;
        var node = (current != null) ? current.Next : null;
        while (node != null) { count++; node = node.Next; }
        return count;
    }

    public void Dispose()
    {
        Clear();
    }
}

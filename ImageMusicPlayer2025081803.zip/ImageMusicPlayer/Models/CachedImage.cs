﻿using System;
using System.Drawing;

namespace ImageMusicPlayer.Models
{
    /// <summary>
    /// 支持缩略图+原图的缓存单元
    /// </summary>
    public class CachedImage : IDisposable
    {
        public string Path { get; }
        public Image? Thumb { get; private set; }
        public Image? Full { get; private set; }
        public bool FullLoaded => Full != null;

        public string Name => System.IO.Path.GetFileName(Path);

        public CachedImage(string path, Image? thumb)
        {
            Path = path;
            Thumb = thumb;
        }

        /// <summary>设置原图（加载完成后调用）</summary>
        public void SetFull(Image img)
        {
            // 原图就绪时可以选择释放缩略图以省内存（可配置）
            Full = img;
            // 若你想保留缩略图以便再次快速缩放，可注释下一行
            // Thumb?.Dispose(); Thumb = null;
        }

        public void Dispose()
        {
            try { Thumb?.Dispose(); } catch { }
            try { Full?.Dispose(); } catch { }
            Thumb = null;
            Full = null;
        }
    }
}

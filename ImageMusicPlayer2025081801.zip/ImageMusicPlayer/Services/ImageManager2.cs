using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using ImageMusicPlayer.Interfaces;
using ImageMusicPlayer.Models;

namespace ImageMusicPlayer.Services
{
    public class ImageManager2 : IImageManager
    {
        private ImageViewer viewer;
        private Action updateStatus;
        private List<string> imagePaths = [];
        private int imageIndex = 0;
        private ImageCache imageCache;
        private CancellationTokenSource slideShowCTS;
        private DateTime lastSwitchTime = DateTime.MinValue; // ���ڷ���
        private const int SwitchDebounceMs = 100; // �������
        private int targetIndex = 0; // Ŀ�����������ڴ��������л�

        // ����ͼƬ�л��Ĳ�����ȫ
        private SemaphoreSlim switchSemaphore = new SemaphoreSlim(1, 1);
        // ���ڱ��� imagePaths ����
        private readonly object imagePathsLock = new object();

        private int pageType = 1; // 1: next ; -1: last 

        public ImageManager2()
        {

        }

        public void Init(ImageViewer viewer, Action updateStatus, int cacheSize)
        {
            this.viewer = viewer;
            this.updateStatus = updateStatus;
            imageCache = new ImageCache(cacheSize);
            imageCache.loadImageFunc = LoadImageFromFile;
        }

        #region ͼƬ����

        public async Task SelectAndLoadFromFolderAsync()
        {
            using (FolderBrowserDialog dialog = new())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    await LoadFromFolderAsync(dialog.SelectedPath);
                }
            }
        }

        public async Task LoadFromFolderAsync(string? folderPath)
        {
            if (folderPath == null)
                throw new ArgumentNullException(nameof(folderPath));

            List<string> newFiles = [];

            await Task.Run(() =>
            {
                newFiles = [.. Directory.EnumerateFiles(folderPath, "*.*", SearchOption.AllDirectories)
                    .Where(f => f.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) ||
                                f.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                                f.EndsWith(".png", StringComparison.OrdinalIgnoreCase))];
            });

            lock (imagePathsLock)
            {
                // ˢ�»��棬ȷ���������������� imagePaths ��Ӧ
                ClearCache();
                var unique = new HashSet<string>(imagePaths, StringComparer.OrdinalIgnoreCase);
                for (int i = newFiles.Count - 1; i >= 0; i--)
                {
                    var file = newFiles[i];
                    if (unique.Add(file))
                        imagePaths.Insert(0, file);
                }
                imageIndex = 0;
            }
            imageCache.Init(imagePaths);
            await ShowImageAsync();
        }

        public async Task SelectAndAppendImagesAsync()
        {
            using (OpenFileDialog dialog = new())
            {
                dialog.Filter = "ͼƬ�ļ�|*.jpg;*.jpeg;*.png";
                dialog.Multiselect = true;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    await Task.Run(() =>
                    {
                        lock (imagePathsLock)
                        {
                            var unique = new HashSet<string>(imagePaths, StringComparer.OrdinalIgnoreCase);
                            foreach (var file in dialog.FileNames)
                            {
                                if (unique.Add(file))
                                    imagePaths.Add(file);
                            }
                        }
                    });
                    lock (imagePathsLock)
                    {
                        if (imageIndex >= imagePaths.Count)
                            imageIndex = 0;
                    }
                    imageCache.Init(imagePaths);
                    pageType = 0; // ��ǰͼƬ
                    await ShowImageAsync();
                }
            }
        }

        public async Task SelectAndAppendImagesAsync(string?[] files)
        {
            await Task.Run(() =>
            {
                lock (imagePathsLock)
                {
                    var unique = new HashSet<string>(imagePaths, StringComparer.OrdinalIgnoreCase);
                    foreach (var file in files)
                    {
                        if (unique.Add(file))
                            imagePaths.Add(file);
                    }
                }
            });
            lock (imagePathsLock)
            {
                if (imageIndex >= imagePaths.Count)
                    imageIndex = 0;
            }
            await ShowImageAsync();
        }

        public async Task RemoveImagesFromFolder(string? folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
                return;

            if (!folderPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
                folderPath += Path.DirectorySeparatorChar;

            string? currentFile;
            lock (imagePathsLock)
            {
                currentFile = imagePaths.Count > imageIndex ? imagePaths[imageIndex] : null;
                imagePaths.RemoveAll(file =>
                {
                    string dir = Path.GetDirectoryName(file);
                    if (string.IsNullOrEmpty(dir))
                        return false;
                    if (!dir.EndsWith(Path.DirectorySeparatorChar.ToString()))
                        dir += Path.DirectorySeparatorChar;
                    return dir.StartsWith(folderPath, StringComparison.OrdinalIgnoreCase);
                });
            }
            ClearCache();
            lock (imagePathsLock)
            {
                if (imagePaths.Count == 0)
                {
                    imageIndex = 0;
                    updateStatus?.Invoke();
                    Debug.WriteLine($"���ļ��� {folderPath} ɾ����ͼƬ����ǰ��ͼƬ��");
                    viewer.LoadImage(null);
                    return;
                }
                else
                {
                    int newIndex = imagePaths.FindIndex(f => f.Equals(currentFile, StringComparison.OrdinalIgnoreCase));
                    if (newIndex != -1)
                    {
                        imageIndex = newIndex;
                    }
                    else
                    {
                        if (imageIndex >= imagePaths.Count)
                            imageIndex = imagePaths.Count - 1;
                    }
                }
            }
            _ = ShowImageAsync();
            Debug.WriteLine($"���ļ��� {folderPath} ɾ��ͼƬ��ɡ�");
            return;
        }

        public Task RemoveImage(string imagePath)
        {
            if (!string.IsNullOrEmpty(imagePath))
            {
                lock (imagePathsLock)
                {
                    imagePaths.RemoveAll(f => f.Equals(imagePath, StringComparison.OrdinalIgnoreCase));
                }
                ClearCache();
                lock (imagePathsLock)
                {
                    if (imagePaths.Count == 0)
                    {
                        imageIndex = 0;
                        updateStatus?.Invoke();
                        viewer.LoadImage(null);
                        Debug.WriteLine($"��ͼƬ�б����Ƴ���ͼƬ��{imagePath}");
                        return null;
                    }
                    else if (imageIndex >= imagePaths.Count)
                    {
                        imageIndex = imagePaths.Count - 1;
                    }
                }
                _ = ShowImageAsync();
                Debug.WriteLine($"��ͼƬ�б����Ƴ���ͼƬ��{imagePath}");
            }
            return null;
        }

        // ��ɾ����ǰͼƬ������Ϊ�첽
        public async Task DeleteCurrentImageAsync()
        {
            lock (imagePathsLock)
            {
                if (imagePaths.Count == 0 || imageIndex < 0 || imageIndex >= imagePaths.Count)
                {
                    Debug.WriteLine($"DeleteCurrentImage: ͼƬ�б�Ϊ�ջ�������Ч��imageIndex={imageIndex}, imagePaths.Count={imagePaths.Count}");
                    return;
                }
                Debug.WriteLine($"DeleteCurrentImage: ��ͼƬ�б����Ƴ���Path={imagePaths[imageIndex]}");
                imagePaths.RemoveAt(imageIndex);
            }
            ClearCache();
            lock (imagePathsLock)
            {
                if (imagePaths.Count == 0)
                {
                    imageIndex = 0;
                    updateStatus?.Invoke();
                    viewer.LoadImage(null);
                    Debug.WriteLine($"DeleteCurrentImage: ͼƬ�б�Ϊ�գ�imageIndex={imageIndex}");
                    return;
                }
                else if (imageIndex >= imagePaths.Count)
                {
                    imageIndex = imagePaths.Count - 1;
                }
            }
            await ShowImageAsync();
        }

        #endregion

        #region ͼƬ��ʾ��Ԥ����

        private async Task ShowImageAsync()
        {
            string pathToLoad = null;
            lock (imagePathsLock)
            {
                if (imagePaths.Count == 0 || imageIndex < 0 || imageIndex >= imagePaths.Count)
                {
                    viewer.LoadImage(null);
                    updateStatus?.Invoke();
                    Debug.WriteLine($"ShowImageAsync: ͼƬ�б�Ϊ�ջ�������Ч��imageIndex={imageIndex}, imagePaths.Count={imagePaths.Count}");
                    return;
                }
                pathToLoad = imagePaths[imageIndex];
            }



            var img = await LoadImageAsync(imageIndex);
            if (img == null)
            {
                Debug.WriteLine($"ShowImageAsync: ����ͼƬʧ�ܣ�imageIndex={imageIndex}, ���Լ�����һ��");
                int attempts = imagePaths.Count;
                while (attempts-- > 0)
                {
                    lock (imagePathsLock)
                    {
                        imageIndex = (imageIndex + 1) % imagePaths.Count;
                        pathToLoad = imagePaths[imageIndex];
                    }
                    img = await LoadImageAsync(imageIndex);
                    if (img != null)
                        break;
                }
            }
            viewer.LoadImage(img);
            updateStatus?.Invoke();
        }


        private async Task<Image?> LoadImageAsync(int index)
        {
            Image? image = null;
            string? filePath = null;
            lock (imagePathsLock)
            {
                if (index < 0 || index >= imagePaths.Count)
                {
                    Debug.WriteLine($"LoadImageAsync: ������Ч��index={index}, imagePaths.Count={imagePaths.Count}");
                    return null;
                }
                filePath = imagePaths[index];

                if (string.IsNullOrEmpty(filePath))
                {
                    Debug.WriteLine($"LoadImageAsync: ͼƬ·��Ϊ�գ�index={index}");
                    return null;
                }

                switch (index)
                {
                    case 0:
                        image = imageCache.GetCurrent().Img;
                        break;
                    default:
                        if (index < imagePaths.Count)
                        {
                            if (pageType == 1)
                            {
                                image = imageCache.Next().Img;
                            }
                        }
                        else
                        if (index > 0)
                        {
                            if (pageType == -1)
                            {
                                image = imageCache.Previous().Img;

                            }
                        }

                        break;
                }

            }
            if (image == null)
            {
                Debug.WriteLine($"LoadImageAsync: �޷�����ͼƬ: {filePath}�������Ƴ�");
                lock (imagePathsLock)
                {
                    if (index < imagePaths.Count && imagePaths[index].Equals(filePath, StringComparison.OrdinalIgnoreCase))
                    {
                        imagePaths.RemoveAt(index);
                        var newCache = new Dictionary<int, Image>();
                        imageCache.Clear();
                        imageCache.Init(imagePaths);
                        pageType = 0; // ��ǰͼƬ
                        if (imagePaths.Count == 0)
                        {
                            imageIndex = 0;
                            return null;
                        }
                        if (index <= imageIndex)
                        {
                            imageIndex = Math.Max(0, imageIndex - 1);
                        }
                    }
                }
            }
            return image;
        }

        private bool IsImageValid(Image img)
        {
            if (img == null)
                return false;
            try
            {
                var width = img.Width;
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"IsImageValid: ͼƬ��Ч������: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// ����ͼƬʱ�����²������������ͼƬ�ߴ糬��Ԥ����ֵ����1920���أ���������һ����С���������ʾ����
        /// </summary>
        private static CachedImage LoadImageFromFile(string filePath)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        fs.CopyTo(ms);
                        byte[] imageData = ms.ToArray();
                        using (MemoryStream msCopy = new MemoryStream(imageData))
                        {
                            Image originalImage = Image.FromStream(msCopy);
                            // �趨���ߴ磬���� 1920 ���أ�����ʵ�����������
                            int maxDimension = 1920;
                            if (originalImage.Width > maxDimension || originalImage.Height > maxDimension)
                            {
                                float scale = Math.Min((float)maxDimension / originalImage.Width, (float)maxDimension / originalImage.Height);
                                int newWidth = (int)(originalImage.Width * scale);
                                int newHeight = (int)(originalImage.Height * scale);
                                Bitmap scaledImage = new Bitmap(newWidth, newHeight);
                                using (Graphics g = Graphics.FromImage(scaledImage))
                                {
                                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                                    g.DrawImage(originalImage, 0, 0, newWidth, newHeight);
                                }
                                originalImage.Dispose();
                                return new CachedImage(filePath, scaledImage);
                            }
                            else
                            {
                                // ���ͼƬ�ߴ粻��ֱ�ӷ���ȫ�ֱ��� Bitmap
                                return new CachedImage(filePath, new Bitmap(originalImage));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"����ͼƬʧ��: {filePath}, ����: {ex.Message}");
                return null;
            }
        }

        private void ClearCache()
        {
            imageCache.Clear();
        }

        #endregion

        #region ͼƬ�������

        public void NextImage()
        {
            _ = NextImageAsync();
        }

        private async Task NextImageAsync()
        {
            // ������м����ڽ��У�ֱ�Ӻ��Ա�������
            if (!switchSemaphore.Wait(0))
            {
                Debug.WriteLine("NextImage: ͼƬ���ؽ����У����Ա����л�����");
                return;
            }
            try
            {
                if (imagePaths.Count == 0)
                {
                    Debug.WriteLine("NextImage: ͼƬ�б�Ϊ��");
                    return;
                }
                // ����Ŀ������
                targetIndex = (targetIndex + 1) % imagePaths.Count;
                if ((DateTime.Now - lastSwitchTime).TotalMilliseconds < SwitchDebounceMs)
                {
                    Debug.WriteLine($"NextImage: �����У�targetIndex={targetIndex}");
                    return;
                }
                imageIndex = targetIndex;
                lastSwitchTime = DateTime.Now;
                // ֻ�м����굱ǰͼƬ����������һ���л�
                await ShowImageAsync();
            }
            finally
            {
                switchSemaphore.Release();
            }
        }

        public void PreviousImage()
        {
            _ = PreviousImageAsync();
        }

        private async Task PreviousImageAsync()
        {
            if (!switchSemaphore.Wait(0))
            {
                Debug.WriteLine("PreviousImage: ͼƬ���ؽ����У����Ա����л�����");
                return;
            }
            try
            {
                if (imagePaths.Count == 0)
                {
                    Debug.WriteLine("PreviousImage: ͼƬ�б�Ϊ��");
                    return;
                }
                targetIndex = (targetIndex - 1 + imagePaths.Count) % imagePaths.Count;
                if ((DateTime.Now - lastSwitchTime).TotalMilliseconds < SwitchDebounceMs)
                {
                    Debug.WriteLine($"PreviousImage: �����У�targetIndex={targetIndex}");
                    return;
                }
                imageIndex = targetIndex;
                lastSwitchTime = DateTime.Now;
                await ShowImageAsync();
            }
            finally
            {
                switchSemaphore.Release();
            }
        }

        public string CurrentImagePath
        {
            get
            {
                lock (imagePathsLock)
                {
                    return imagePaths.Count > 0 && imageIndex < imagePaths.Count ? imagePaths[imageIndex] : null;
                }
            }
        }
        public int CurrentIndex => imageIndex;
        public int TotalCount
        {
            get
            {
                lock (imagePathsLock)
                {
                    return imagePaths.Count;
                }
            }
        }
        public int CacheCount
        {
            get
            {
                lock (imageCache)
                {
                    return imageCache.CurrentCachedSize;
                }
            }
        }

        #endregion

        #region �õ�Ƭ����

        /// <summary>
        /// �����õ�Ƭ���ţ�ʹ�ö�̬��ʱ������ͨ��ί�л�ȡ������ʱֵ��
        /// </summary>
        public async Task StartSlideShowAsync(Func<int> getDelay)
        {
            PauseSlideShow();
            slideShowCTS = new CancellationTokenSource();
            CancellationToken token = slideShowCTS.Token;
            try
            {
                while (!token.IsCancellationRequested)
                {
                    NextImage();
                    int currentDelay = getDelay();
                    await Task.Delay(currentDelay, token);
                }
            }
            catch (TaskCanceledException)
            {
                // ����ȡ���쳣
            }
        }

        /// <summary>
        /// ��ͣ�õ�Ƭ����
        /// </summary>
        public void PauseSlideShow()
        {
            if (slideShowCTS != null)
            {
                slideShowCTS.Cancel();
                slideShowCTS.Dispose();
                slideShowCTS = null;
            }
        }
        #endregion
    }
}

using Microsoft.Extensions.DependencyInjection;

namespace ImageMusicPlayer
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // ���� DI ����
            IServiceProvider serviceProvider = Startup.ConfigureServices();
            // ��ȡ MainForm ʵ��������
            MainForm mainForm = serviceProvider.GetRequiredService<MainForm>();
            
            Application.Run(mainForm);
        }
    }
}